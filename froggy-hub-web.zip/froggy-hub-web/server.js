// Froggy Hub — servidor HTTP sin framework.
// Sirve /public, guarda los scripts y hace de puente seguro hacia Roblox y Gemini
// (la API key de Gemini nunca llega al navegador).
import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.join(__dirname, 'public');

const PORT = Number(process.env.PORT) || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const DATABASE_URL = process.env.DATABASE_URL || '';
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const MAX_SCRIPTS = 500;

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

/* ------------------------------------------------------------------ */
/* Almacenamiento: Postgres si hay DATABASE_URL, si no un archivo JSON */
/* ------------------------------------------------------------------ */

async function createFileStore() {
  const file = path.join(DATA_DIR, 'scripts.json');
  let queue = Promise.resolve();

  async function read() {
    try {
      return JSON.parse(await fs.readFile(file, 'utf8'));
    } catch (err) {
      if (err.code === 'ENOENT') return [];
      throw err;
    }
  }
  async function write(list) {
    await fs.mkdir(DATA_DIR, { recursive: true });
    const tmp = `${file}.tmp`;
    await fs.writeFile(tmp, JSON.stringify(list, null, 2));
    await fs.rename(tmp, file);
  }
  // Serializa las escrituras para que dos peticiones no se pisen.
  const serial = (fn) => {
    const run = queue.then(fn);
    queue = run.catch(() => {});
    return run;
  };

  return {
    kind: 'archivo JSON',
    async list() {
      return (await read()).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    },
    add: (item) =>
      serial(async () => {
        const list = await read();
        list.push(item);
        await write(list);
        return item;
      }),
    remove: (id) =>
      serial(async () => {
        const list = await read();
        const next = list.filter((x) => x.id !== id);
        await write(next);
        return next.length !== list.length;
      }),
  };
}

async function createPgStore() {
  const { default: pg } = await import('pg');
  const needsSsl = /\.render\.com/.test(DATABASE_URL) || process.env.PGSSLMODE === 'require';
  const pool = new pg.Pool({
    connectionString: DATABASE_URL,
    ssl: needsSsl ? { rejectUnauthorized: false } : undefined,
    max: 5,
  });
  await pool.query(`
    CREATE TABLE IF NOT EXISTS scripts (
      id TEXT PRIMARY KEY,
      universe_id TEXT NOT NULL,
      name TEXT NOT NULL,
      thumbnail TEXT,
      description TEXT NOT NULL,
      ai_generated BOOLEAN NOT NULL DEFAULT FALSE,
      loadstring_url TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )`);

  const toItem = (r) => ({
    id: r.id,
    universeId: r.universe_id,
    name: r.name,
    thumbnail: r.thumbnail,
    description: r.description,
    aiGenerated: r.ai_generated,
    loadstringUrl: r.loadstring_url,
    createdAt: r.created_at.toISOString(),
  });

  return {
    kind: 'Postgres',
    async list() {
      const { rows } = await pool.query('SELECT * FROM scripts ORDER BY created_at DESC');
      return rows.map(toItem);
    },
    async add(item) {
      await pool.query(
        `INSERT INTO scripts (id, universe_id, name, thumbnail, description, ai_generated, loadstring_url, created_at)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
        [item.id, item.universeId, item.name, item.thumbnail, item.description, item.aiGenerated, item.loadstringUrl, item.createdAt],
      );
      return item;
    },
    async remove(id) {
      const res = await pool.query('DELETE FROM scripts WHERE id = $1', [id]);
      return res.rowCount > 0;
    },
  };
}

/* ------------------------------------------------------------------ */
/* Utilidades                                                          */
/* ------------------------------------------------------------------ */

const buckets = new Map();
function bump(key, windowMs) {
  const now = Date.now();
  let b = buckets.get(key);
  if (!b || b.reset < now) {
    b = { n: 0, reset: now + windowMs };
    buckets.set(key, b);
  }
  b.n += 1;
  return b.n;
}
function peek(key) {
  const b = buckets.get(key);
  return b && b.reset > Date.now() ? b.n : 0;
}
setInterval(() => {
  const now = Date.now();
  for (const [k, b] of buckets) if (b.reset < now) buckets.delete(k);
}, 60_000).unref();

function clientIp(req) {
  return (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress || 'unknown';
}

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'content-length': Buffer.byteLength(body),
  });
  res.end(body);
}

async function readJson(req, limit = 16 * 1024) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > limit) throw new HttpError(413, 'La petición es demasiado grande.');
    chunks.push(chunk);
  }
  if (!size) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw new HttpError(400, 'El cuerpo de la petición no es JSON válido.');
  }
}

function cleanText(value, max) {
  return String(value ?? '')
    .replace(/[\u0000-\u001f\u007f]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, max);
}

function requireAdmin(req) {
  if (!ADMIN_PASSWORD) {
    throw new HttpError(503, 'Las subidas están desactivadas: define ADMIN_PASSWORD en el servidor.');
  }
  const ip = clientIp(req);
  if (peek(`fail:${ip}`) >= 10) {
    throw new HttpError(429, 'Demasiados intentos fallidos. Espera unos minutos.');
  }
  const hash = (s) => crypto.createHash('sha256').update(s).digest();
  const given = String(req.headers['x-admin-password'] || '');
  if (!crypto.timingSafeEqual(hash(given), hash(ADMIN_PASSWORD))) {
    bump(`fail:${ip}`, 10 * 60_000);
    throw new HttpError(401, 'Contraseña de admin incorrecta.');
  }
}

function parseLoadstringUrl(raw) {
  let url;
  try {
    url = new URL(String(raw ?? '').trim());
  } catch {
    throw new HttpError(400, 'La URL del loadstring no es válida.');
  }
  if (url.protocol !== 'https:' && url.protocol !== 'http:') {
    throw new HttpError(400, 'La URL del loadstring debe empezar con http:// o https://.');
  }
  if (url.href.length > 600) throw new HttpError(400, 'La URL del loadstring es demasiado larga.');
  return url.href; // href ya viene codificada: no puede cerrar las comillas del loadstring
}

/* ------------------------------------------------------------------ */
/* Roblox                                                              */
/* ------------------------------------------------------------------ */

const RBX_HEADERS = { 'user-agent': 'FroggyHub/1.0', accept: 'application/json' };
const robloxCache = new Map();
const isRbxImage = (u) => typeof u === 'string' && /^https:\/\/[a-z0-9.-]+\.rbxcdn\.com\//i.test(u);

async function getJson(url) {
  const res = await fetch(url, { headers: RBX_HEADERS, signal: AbortSignal.timeout(8000) });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function getRobloxGame(universeId) {
  const cached = robloxCache.get(universeId);
  if (cached && cached.expires > Date.now()) return cached.value;

  let games;
  try {
    games = await getJson(`https://games.roblox.com/v1/games?universeIds=${universeId}`);
  } catch {
    throw new HttpError(502, 'No pude consultar Roblox ahora mismo. Inténtalo de nuevo en un momento.');
  }
  const game = games?.data?.[0];
  if (!game) throw new HttpError(404, 'Roblox no encontró ningún juego con ese ID de universo.');

  // 1) miniatura grande del juego; 2) si no hay, el icono.
  let thumbnail = null;
  try {
    const t = await getJson(
      `https://thumbnails.roblox.com/v1/games/multiget/thumbnails?universeIds=${universeId}&countPerUniverse=1&size=768x432&format=Png&isCircular=false`,
    );
    thumbnail = t?.data?.[0]?.thumbnails?.[0]?.imageUrl || null;
  } catch {
    /* seguimos con el icono */
  }
  if (!isRbxImage(thumbnail)) {
    try {
      const i = await getJson(
        `https://thumbnails.roblox.com/v1/games/icons?universeIds=${universeId}&size=256x256&format=Png&isCircular=false`,
      );
      thumbnail = i?.data?.[0]?.imageUrl || null;
    } catch {
      thumbnail = null;
    }
  }

  const value = {
    universeId,
    name: cleanText(game.name, 80) || `Juego ${universeId}`,
    thumbnail: isRbxImage(thumbnail) ? thumbnail : null,
  };
  robloxCache.set(universeId, { value, expires: Date.now() + 10 * 60_000 });
  return value;
}

/* ------------------------------------------------------------------ */
/* Gemini                                                              */
/* ------------------------------------------------------------------ */

async function generateDescription(gameName) {
  if (!GEMINI_API_KEY) throw new HttpError(503, 'Falta GEMINI_API_KEY en el servidor.');
  const name = cleanText(gameName, 80);
  if (!name) throw new HttpError(400, 'Escribe el nombre del juego para generar la descripción.');

  const prompt =
    `Genera una descripción corta y atractiva (máximo 2 líneas) con tono amigable y kawaii ` +
    `para un script del juego de Roblox "${name}". ` +
    `Responde solo con la descripción, en español, sin comillas ni formato markdown.`;

  let text;
  try {
    const { GoogleGenAI } = await import('@google/genai');
    const ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY });
    const response = await ai.models.generateContent({ model: GEMINI_MODEL, contents: prompt });
    text = response.text;
  } catch (err) {
    if (err?.code !== 'ERR_MODULE_NOT_FOUND') {
      console.error('Gemini (SDK):', err?.message || err);
      throw new HttpError(502, 'Gemini no pudo generar la descripción. Revisa la API key o el modelo.');
    }
    // El SDK no está instalado (por ejemplo en local): usamos la API REST.
    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(GEMINI_MODEL)}:generateContent`,
      {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-goog-api-key': GEMINI_API_KEY },
        body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] }),
        signal: AbortSignal.timeout(15000),
      },
    );
    if (!res.ok) {
      console.error('Gemini (REST):', res.status);
      throw new HttpError(502, 'Gemini no pudo generar la descripción. Revisa la API key o el modelo.');
    }
    const data = await res.json();
    text = data?.candidates?.[0]?.content?.parts?.map((p) => p.text).join('') || '';
  }

  const description = cleanText(String(text || '').replace(/[*_`#>]/g, ''), 220);
  if (!description) throw new HttpError(502, 'Gemini devolvió una respuesta vacía.');
  return description;
}

/* ------------------------------------------------------------------ */
/* Rutas de la API                                                     */
/* ------------------------------------------------------------------ */

function createApi(store) {
  return async function handleApi(req, res, pathname) {
    const method = req.method;

    if (pathname === '/api/config' && method === 'GET') {
      return sendJson(res, 200, {
        adminEnabled: Boolean(ADMIN_PASSWORD),
        aiEnabled: Boolean(GEMINI_API_KEY),
      });
    }

    if (pathname === '/api/scripts' && method === 'GET') {
      return sendJson(res, 200, { scripts: await store.list() });
    }

    const robloxMatch = pathname.match(/^\/api\/roblox\/(\d{1,15})$/);
    if (robloxMatch && method === 'GET') {
      if (bump(`rbx:${clientIp(req)}`, 60_000) > 40) throw new HttpError(429, 'Demasiadas consultas, espera un momento.');
      return sendJson(res, 200, await getRobloxGame(robloxMatch[1]));
    }

    if (pathname === '/api/auth' && method === 'POST') {
      requireAdmin(req);
      return sendJson(res, 200, { ok: true });
    }

    if (pathname === '/api/describe' && method === 'POST') {
      requireAdmin(req);
      if (bump(`ai:${clientIp(req)}`, 60_000) > 12) throw new HttpError(429, 'Demasiadas descripciones seguidas, espera un momento.');
      const { name } = await readJson(req);
      return sendJson(res, 200, { description: await generateDescription(name) });
    }

    if (pathname === '/api/scripts' && method === 'POST') {
      requireAdmin(req);
      const body = await readJson(req);

      const universeId = String(body.universeId ?? '').trim();
      if (!/^\d{1,15}$/.test(universeId)) {
        throw new HttpError(400, 'El ID del universo debe ser un número.');
      }
      const loadstringUrl = parseLoadstringUrl(body.loadstringUrl);
      if ((await store.list()).length >= MAX_SCRIPTS) {
        throw new HttpError(409, `Límite de ${MAX_SCRIPTS} scripts alcanzado.`);
      }

      const game = await getRobloxGame(universeId);
      const name = cleanText(body.name, 80) || game.name;

      let description = cleanText(body.description, 220);
      let aiGenerated = Boolean(description) && body.aiGenerated === true;
      let warning;
      if (!description) {
        try {
          description = await generateDescription(name);
          aiGenerated = true;
        } catch (err) {
          warning = `Publicado sin descripción de IA: ${err.message}`;
          description = `Script para ${name}, listo para copiar y pegar. ¡A saltar! 🐸`;
        }
      }

      const item = {
        id: crypto.randomUUID(),
        universeId,
        name,
        thumbnail: game.thumbnail,
        description,
        aiGenerated,
        loadstringUrl,
        createdAt: new Date().toISOString(),
      };
      await store.add(item);
      return sendJson(res, 201, { script: item, warning });
    }

    const deleteMatch = pathname.match(/^\/api\/scripts\/([0-9a-f-]{36})$/);
    if (deleteMatch && method === 'DELETE') {
      requireAdmin(req);
      const removed = await store.remove(deleteMatch[1]);
      if (!removed) throw new HttpError(404, 'Ese script ya no existe.');
      return sendJson(res, 200, { ok: true });
    }

    throw new HttpError(404, 'Ruta no encontrada.');
  };
}

/* ------------------------------------------------------------------ */
/* Archivos estáticos                                                  */
/* ------------------------------------------------------------------ */

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.json': 'application/json; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
};

async function serveStatic(req, res, pathname) {
  let decoded;
  try {
    decoded = decodeURIComponent(pathname === '/' ? '/index.html' : pathname);
  } catch {
    throw new HttpError(400, 'Ruta inválida.');
  }
  const file = path.normalize(path.join(PUBLIC_DIR, decoded));
  if (!file.startsWith(PUBLIC_DIR + path.sep)) throw new HttpError(404, 'No encontrado.');

  let data;
  try {
    data = await fs.readFile(file);
  } catch {
    throw new HttpError(404, 'No encontrado.');
  }
  const ext = path.extname(file).toLowerCase();
  res.writeHead(200, {
    'content-type': MIME[ext] || 'application/octet-stream',
    'cache-control': ext === '.html' ? 'no-cache' : 'public, max-age=3600',
    'content-length': data.length,
  });
  res.end(req.method === 'HEAD' ? undefined : data);
}

/* ------------------------------------------------------------------ */
/* Arranque                                                            */
/* ------------------------------------------------------------------ */

const SECURITY_HEADERS = {
  'content-security-policy': [
    "default-src 'self'",
    "img-src 'self' data: https://*.rbxcdn.com",
    "style-src 'self' https://fonts.googleapis.com",
    "font-src https://fonts.gstatic.com",
    "script-src 'self'",
    "connect-src 'self'",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'none'",
  ].join('; '),
  'x-content-type-options': 'nosniff',
  'referrer-policy': 'no-referrer',
  'x-frame-options': 'DENY',
};

async function main() {
  const store = DATABASE_URL ? await createPgStore() : await createFileStore();
  const handleApi = createApi(store);

  const server = http.createServer(async (req, res) => {
    for (const [k, v] of Object.entries(SECURITY_HEADERS)) res.setHeader(k, v);
    try {
      const { pathname } = new URL(req.url, 'http://localhost');
      if (pathname === '/healthz') return sendJson(res, 200, { ok: true });
      if (pathname.startsWith('/api/')) return await handleApi(req, res, pathname);
      if (req.method !== 'GET' && req.method !== 'HEAD') throw new HttpError(405, 'Método no permitido.');
      await serveStatic(req, res, pathname);
    } catch (err) {
      if (res.headersSent) return res.end();
      if (err instanceof HttpError) return sendJson(res, err.status, { error: err.message });
      console.error(err);
      sendJson(res, 500, { error: 'Algo salió mal en el servidor.' });
    }
  });

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Froggy Hub escuchando en el puerto ${PORT}`);
    console.log(`  almacenamiento: ${store.kind}`);
    console.log(`  subidas: ${ADMIN_PASSWORD ? 'activadas' : 'DESACTIVADAS (falta ADMIN_PASSWORD)'}`);
    console.log(`  Gemini: ${GEMINI_API_KEY ? `activado (${GEMINI_MODEL})` : 'desactivado (falta GEMINI_API_KEY)'}`);
  });
}

main().catch((err) => {
  console.error('No pude arrancar:', err);
  process.exit(1);
});
